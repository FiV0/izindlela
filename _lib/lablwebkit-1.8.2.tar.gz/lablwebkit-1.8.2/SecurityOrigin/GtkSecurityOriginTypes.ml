type securityorigin = [ `securityorigin | `gtk ]


