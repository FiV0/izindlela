open Gobject
open Data
open GtkWebkitTypes
module SecurityOrigin = struct
  include GtkSecurityOriginProps.SecurityOrigin
  
  
end