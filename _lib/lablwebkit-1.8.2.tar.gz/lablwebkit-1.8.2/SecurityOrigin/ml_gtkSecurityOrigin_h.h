#include "SecurityOrigin/ml_gtkSecurityOrigin_tags_h.h"

#define WebkitSecurityOrigin_val(val) check_cast(WEBKIT_SECURITY_ORIGIN,val)
#define Val_webkit_security_origin(val) Val_GtkAny(val)
