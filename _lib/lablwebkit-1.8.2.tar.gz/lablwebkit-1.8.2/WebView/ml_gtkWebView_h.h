#include "WebView/ml_gtkWebView_tags_h.h"

#define WebkitWebView_val(val) check_cast(WEBKIT_WEB_VIEW,val)
#define Val_webkit_web_view(val) Val_GtkAny(val)
