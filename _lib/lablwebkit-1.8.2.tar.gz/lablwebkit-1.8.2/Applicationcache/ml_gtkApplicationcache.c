#include "ml_gtkWebkit.h"
#include "ml_gtkApplicationcache_tags_c.h"



ML_0(webkit_application_cache_get_maximum_size, Val_long)

ML_1(webkit_application_cache_set_maximum_size, Long_val, Unit)

ML_0(webkit_application_cache_get_database_directory_path, Val_string)

