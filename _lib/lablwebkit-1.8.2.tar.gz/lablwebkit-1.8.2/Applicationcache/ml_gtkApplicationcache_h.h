#include "Applicationcache/ml_gtkApplicationcache_tags_h.h"

#define WebkitApplicationcache_val(val) check_cast(WEBKIT_APPLICATIONCACHE,val)
#define Val_webkit_applicationcache(val) Val_GtkAny(val)
