#include "Dom/ml_gtkDom_tags_h.h"

#define WebkitDom_val(val) check_cast(WEBKIT_DOM,val)
#define Val_webkit_dom(val) Val_GtkAny(val)
