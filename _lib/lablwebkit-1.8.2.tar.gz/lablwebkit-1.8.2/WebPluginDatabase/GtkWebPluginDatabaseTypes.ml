type webplugindatabase = [ `webplugindatabase | `gtk ]


