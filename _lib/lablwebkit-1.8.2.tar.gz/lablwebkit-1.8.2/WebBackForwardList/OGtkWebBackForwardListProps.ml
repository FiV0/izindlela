open GtkSignal
open Gobject
open Data
let set = set
let get = get
let param = param
open GtkWebBackForwardListProps

