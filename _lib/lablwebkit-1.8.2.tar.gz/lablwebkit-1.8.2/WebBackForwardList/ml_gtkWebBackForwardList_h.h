#include "WebBackForwardList/ml_gtkWebBackForwardList_tags_h.h"

#define WebkitWebBackForwardList_val(val) check_cast(WEBKIT_WEB_BACK_FORWARD_LIST,val)
#define Val_webkit_web_back_forward_list(val) Val_GtkAny(val)
