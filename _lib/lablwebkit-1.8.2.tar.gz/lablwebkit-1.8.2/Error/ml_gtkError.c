#include "ml_gtkWebkit.h"
#include "ml_gtkError_tags_c.h"

#define WebkitNetworkError_val Webkit_network_error_val
#define WebkitPolicyError_val Webkit_policy_error_val
#define WebkitPluginError_val Webkit_plugin_error_val



