#include "WebHistoryItem/ml_gtkWebHistoryItem_tags_h.h"

#define WebkitWebHistoryItem_val(val) check_cast(WEBKIT_WEB_HISTORY_ITEM,val)
#define Val_webkit_web_history_item(val) Val_GtkAny(val)
