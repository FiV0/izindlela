#include "Defines/ml_gtkDefines_tags_h.h"

#define WebkitDefines_val(val) check_cast(WEBKIT_DEFINES,val)
#define Val_webkit_defines(val) Val_GtkAny(val)
