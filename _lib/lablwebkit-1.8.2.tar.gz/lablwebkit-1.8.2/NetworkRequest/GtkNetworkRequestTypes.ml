type networkrequest = [ `networkrequest | `gtk ]


