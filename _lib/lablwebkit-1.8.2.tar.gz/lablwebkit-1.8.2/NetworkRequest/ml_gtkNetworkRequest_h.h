#include "NetworkRequest/ml_gtkNetworkRequest_tags_h.h"

#define WebkitNetworkRequest_val(val) check_cast(WEBKIT_NETWORK_REQUEST,val)
#define Val_webkit_network_request(val) Val_GtkAny(val)
