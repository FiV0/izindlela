type webplugin = [ `webplugin | `gtk ]


