#include "IconDatabase/ml_gtkIconDatabase_tags_h.h"

#define WebkitIconDatabase_val(val) check_cast(WEBKIT_ICON_DATABASE,val)
#define Val_webkit_icon_database(val) Val_GtkAny(val)
