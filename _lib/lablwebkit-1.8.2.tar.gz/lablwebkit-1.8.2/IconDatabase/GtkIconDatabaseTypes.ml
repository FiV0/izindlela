type icondatabase = [ `icondatabase | `gtk ]


