type webnavigationaction = [ `webnavigationaction | `gtk ]


