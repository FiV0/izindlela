#include "WebNavigationAction/ml_gtkWebNavigationAction_tags_h.h"

#define WebkitWebNavigationAction_val(val) check_cast(WEBKIT_WEB_NAVIGATION_ACTION,val)
#define Val_webkit_web_navigation_action(val) Val_GtkAny(val)
