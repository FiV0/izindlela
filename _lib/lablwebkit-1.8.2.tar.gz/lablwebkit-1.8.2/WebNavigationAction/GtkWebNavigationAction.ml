open Gobject
open Data
open GtkWebkitTypes
module WebNavigationAction = struct
  include GtkWebNavigationActionProps.WebNavigationAction
  
  
end