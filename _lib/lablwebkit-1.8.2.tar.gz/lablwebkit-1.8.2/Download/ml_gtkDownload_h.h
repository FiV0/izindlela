#include "Download/ml_gtkDownload_tags_h.h"

#define WebkitDownload_val(val) check_cast(WEBKIT_DOWNLOAD,val)
#define Val_webkit_download(val) Val_GtkAny(val)
