type download = [ `download | `gtk ]


