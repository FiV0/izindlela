type geolocationpolicydecision = [ `geolocationpolicydecision | `gtk ]


