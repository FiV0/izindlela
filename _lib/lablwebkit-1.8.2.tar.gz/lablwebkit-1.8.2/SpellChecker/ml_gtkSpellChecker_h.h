#include "SpellChecker/ml_gtkSpellChecker_tags_h.h"

#define WebkitSpellChecker_val(val) check_cast(WEBKIT_SPELL_CHECKER,val)
#define Val_webkit_spell_checker(val) Val_GtkAny(val)
