open Gobject
open Data
open GtkWebkitTypes
module SpellChecker = struct
  
end