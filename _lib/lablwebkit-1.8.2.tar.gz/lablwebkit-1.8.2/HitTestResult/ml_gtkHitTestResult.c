#include "ml_gtkWebkit.h"
#include "ml_gtkHitTestResult_tags_c.h"

#define WebkitHitTestResultContext_val Webkit_hit_test_result_context_val

ML_0(webkit_hit_test_result_get_type, Val_gtype)

