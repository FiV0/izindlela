type hittestresult = [ `hittestresult | `gtk ]


