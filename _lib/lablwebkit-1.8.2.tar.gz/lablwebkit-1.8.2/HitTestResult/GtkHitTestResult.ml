open Gobject
open Data
open GtkWebkitTypes
module HitTestResult = struct
  include GtkHitTestResultProps.HitTestResult
  
  
end