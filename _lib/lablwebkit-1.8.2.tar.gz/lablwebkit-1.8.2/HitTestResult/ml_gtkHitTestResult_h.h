#include "HitTestResult/ml_gtkHitTestResult_tags_h.h"

#define WebkitHitTestResult_val(val) check_cast(WEBKIT_HIT_TEST_RESULT,val)
#define Val_webkit_hit_test_result(val) Val_GtkAny(val)
