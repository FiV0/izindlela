#include "WebFrame/ml_gtkWebFrame_tags_h.h"

#define WebkitWebFrame_val(val) check_cast(WEBKIT_WEB_FRAME,val)
#define Val_webkit_web_frame(val) Val_GtkAny(val)
