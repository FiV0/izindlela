#include "ml_gtkWebkit.h"
#include "ml_gtkViewportAttributes_tags_c.h"



ML_0(webkit_viewport_attributes_get_type, Val_gtype)

ML_1(webkit_viewport_attributes_recompute, WebkitViewportAttributes_val, Unit)

