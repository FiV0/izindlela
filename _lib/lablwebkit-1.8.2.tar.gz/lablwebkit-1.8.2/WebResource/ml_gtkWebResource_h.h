#include "WebResource/ml_gtkWebResource_tags_h.h"

#define WebkitWebResource_val(val) check_cast(WEBKIT_WEB_RESOURCE,val)
#define Val_webkit_web_resource(val) Val_GtkAny(val)
