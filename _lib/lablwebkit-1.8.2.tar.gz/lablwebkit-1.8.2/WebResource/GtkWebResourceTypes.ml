type webresource = [ `webresource | `gtk ]


