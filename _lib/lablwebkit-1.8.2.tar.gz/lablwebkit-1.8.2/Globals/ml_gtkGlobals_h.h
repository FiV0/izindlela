#include "Globals/ml_gtkGlobals_tags_h.h"

#define WebkitGlobals_val(val) check_cast(WEBKIT_GLOBALS,val)
#define Val_webkit_globals(val) Val_GtkAny(val)
