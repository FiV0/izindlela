#include "WebDataSource/ml_gtkWebDataSource_tags_h.h"

#define WebkitWebDataSource_val(val) check_cast(WEBKIT_WEB_DATA_SOURCE,val)
#define Val_webkit_web_data_source(val) Val_GtkAny(val)
