#include "FaviconDatabase/ml_gtkFaviconDatabase_tags_h.h"

#define WebkitFaviconDatabase_val(val) check_cast(WEBKIT_FAVICON_DATABASE,val)
#define Val_webkit_favicon_database(val) Val_GtkAny(val)
