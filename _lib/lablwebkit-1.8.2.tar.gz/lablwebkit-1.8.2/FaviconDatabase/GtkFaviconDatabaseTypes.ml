type favicondatabase = [ `favicondatabase | `gtk ]


