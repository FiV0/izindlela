#include "WebPolicyDecision/ml_gtkWebPolicyDecision_tags_h.h"

#define WebkitWebPolicyDecision_val(val) check_cast(WEBKIT_WEB_POLICY_DECISION,val)
#define Val_webkit_web_policy_decision(val) Val_GtkAny(val)
