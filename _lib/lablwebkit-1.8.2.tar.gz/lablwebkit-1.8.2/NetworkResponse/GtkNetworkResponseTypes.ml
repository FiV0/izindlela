type networkresponse = [ `networkresponse | `gtk ]


