#include "Domdefines/ml_gtkDomdefines_tags_h.h"

#define WebkitDomdefines_val(val) check_cast(WEBKIT_DOMDEFINES,val)
#define Val_webkit_domdefines(val) Val_GtkAny(val)
